# Shopify Portfolio

This is a single-page portfolio website for Shopify/e-commerce job applications.

IMPORTANT:
- The three stores are self-initiated concept projects.
- Do not describe them as client work.
- Replace YOUR-EMAIL@example.com in index.html with your real email.
- Replace the name if you want a different professional name.

To preview:
1. Open index.html in a browser.
2. Upload the folder to your preferred static hosting service when ready.
